#!/bin/bash
KANGODIR="../.."
python $KANGODIR/kango.py build ./
