Kango - Cross-browser extension framework. 

Website: http://kangoextensions.com/
Documentation: http://kangoextensions.com/docs/
Samples: https://github.com/KangoExtensions/kango-samples
Issue tracker: https://github.com/KangoExtensions/kango/issues