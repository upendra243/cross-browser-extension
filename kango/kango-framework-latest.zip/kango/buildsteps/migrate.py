from kango.buildsteps import BuildStepBase


class BuildStep(BuildStepBase):

    def pre_pack(self, output_path, project_path, info, args):
        pass
