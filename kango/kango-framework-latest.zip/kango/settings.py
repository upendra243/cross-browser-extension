import os
import json


VERSION = '1.8.0'
BUILD = '3dc957b83b36'
PACKAGE_ID = 'dev'

KEYWORDS = {
    "product": "kango",
    "ie.engine": "KangoEngine",
    "ie.bho": "KangoBHO"
}
